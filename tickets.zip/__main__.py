from utils.loader import client

if __name__ == "__main__":
    client().__run__()